from django.apps import AppConfig


class MycompilerConfig(AppConfig):
    name = 'mycompiler'
