function showq1(bool_value){
    document.getElementById('q1').style.display="block";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b1').style.border="1.5px solid #FF1744";
    }
  }
  function showq2(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="block";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b2').style.border="1.5px solid #FF1744";
      document.getElementById('b1').style.border="1.5px solid #00bfff";
    }
  }
  function showq3(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="block";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b3').style.border="1.5px solid #FF1744";
      document.getElementById('b2').style.border="1.5px solid #00bfff";
    }
  }
  function showq4(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="block";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b4').style.border="1.5px solid #FF1744";
      document.getElementById('b3').style.border="1.5px solid #00bfff";
    }
  }
  function showq5(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="block";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b5').style.border="1.5px solid #FF1744";
      document.getElementById('b4').style.border="1.5px solid #00bfff";
    }
  }
  function showq6(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="block";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b6').style.border="1.5px solid #FF1744";
      document.getElementById('b5').style.border="1.5px solid #00bfff";
    }
  }
  function showq7(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="block";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b7').style.border="1.5px solid #FF1744";
      document.getElementById('b6').style.border="1.5px solid #00bfff";
    }
  }
  function showq8(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="block";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b8').style.border="1.5px solid #FF1744";
      document.getElementById('b7').style.border="1.5px solid #00bfff";
    }
  }
  function showq9(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="block";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b9').style.border="1.5px solid #FF1744";
      document.getElementById('b8').style.border="1.5px solid #00bfff";
    }
  }
  function showq10(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="block";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b10').style.border="1.5px solid #FF1744";
      document.getElementById('b9').style.border="1.5px solid #00bfff";
    }
  }
  function showq11(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="block";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b11').style.border="1.5px solid #FF1744";
      document.getElementById('b10').style.border="1.5px solid #00bfff";
    }
  }
  function showq12(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="block";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b12').style.border="1.5px solid #FF1744";
      document.getElementById('b11').style.border="1.5px solid #00bfff";
    }
  }
  function showq13(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="block";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b13').style.border="1.5px solid #FF1744";
      document.getElementById('b12').style.border="1.5px solid #00bfff";
    }
  }
  function showq14(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="block";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b14').style.border="1.5px solid #FF1744";
      document.getElementById('b13').style.border="1.5px solid #00bfff";
    }
  }
  function showq15(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="block";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b15').style.border="1.5px solid #FF1744";
      document.getElementById('b14').style.border="1.5px solid #00bfff";
    }
  }
  function showq16(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="block";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b16').style.border="1.5px solid #FF1744";
      document.getElementById('b15').style.border="1.5px solid #00bfff";
    }
  }
  function showq17(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="block";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b17').style.border="1.5px solid #FF1744";
      document.getElementById('b16').style.border="1.5px solid #00bfff";
    }
  }
  function showq18(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="block";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b18').style.border="1.5px solid #FF1744";
      document.getElementById('b17').style.border="1.5px solid #00bfff";
    }
  }
  function showq19(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="block";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b19').style.border="1.5px solid #FF1744";
      document.getElementById('b18').style.border="1.5px solid #00bfff";
    }
  }
  function showq20(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="block";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b20').style.border="1.5px solid #FF1744";
      document.getElementById('b19').style.border="1.5px solid #00bfff";
    }
  }




  function showq21(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="block";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b21').style.border="1.5px solid #FF1744";
      document.getElementById('b20').style.border="1.5px solid #00bfff";
    }
  }
  function showq22(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="block";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b22').style.border="1.5px solid #FF1744";
      document.getElementById('b21').style.border="1.5px solid #00bfff";
    }
  }
  function showq23(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="block";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b23').style.border="1.5px solid #FF1744";
      document.getElementById('b22').style.border="1.5px solid #00bfff";
    }
  }
  function showq24(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="block";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b24').style.border="1.5px solid #FF1744";
      document.getElementById('b23').style.border="1.5px solid #00bfff";
    }
  }
  function showq25(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="block";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b25').style.border="1.5px solid #FF1744";
      document.getElementById('b24').style.border="1.5px solid #00bfff";
    }
  }
  function showq26(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="block";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b26').style.border="1.5px solid #FF1744";
      document.getElementById('b25').style.border="1.5px solid #00bfff";
    }
  }
  function showq27(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="block";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b27').style.border="1.5px solid #FF1744";
      document.getElementById('b26').style.border="1.5px solid #00bfff";
    }
  }
  function showq28(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="block";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b28').style.border="1.5px solid #FF1744";
      document.getElementById('b27').style.border="1.5px solid #00bfff";
    }
  }
  function showq29(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="block";
    document.getElementById('q30').style.display="none";
    if (!bool_value) {  
      document.getElementById('b29').style.border="1.5px solid #FF1744";
      document.getElementById('b28').style.border="1.5px solid #00bfff";
    }
  }
  function showq30(bool_value){
    document.getElementById('q1').style.display="none";
    document.getElementById('q2').style.display="none";
    document.getElementById('q3').style.display="none";
    document.getElementById('q4').style.display="none";
    document.getElementById('q5').style.display="none";
    document.getElementById('q6').style.display="none";
    document.getElementById('q7').style.display="none";
    document.getElementById('q8').style.display="none";
    document.getElementById('q9').style.display="none";
    document.getElementById('q10').style.display="none";
    document.getElementById('q11').style.display="none";
    document.getElementById('q12').style.display="none";
    document.getElementById('q13').style.display="none";
    document.getElementById('q14').style.display="none";
    document.getElementById('q15').style.display="none";
    document.getElementById('q16').style.display="none";
    document.getElementById('q17').style.display="none";
    document.getElementById('q18').style.display="none";
    document.getElementById('q19').style.display="none";
    document.getElementById('q20').style.display="none";
    document.getElementById('q21').style.display="none";
    document.getElementById('q22').style.display="none";
    document.getElementById('q23').style.display="none";
    document.getElementById('q24').style.display="none";
    document.getElementById('q25').style.display="none";
    document.getElementById('q26').style.display="none";
    document.getElementById('q27').style.display="none";
    document.getElementById('q28').style.display="none";
    document.getElementById('q29').style.display="none";
    document.getElementById('q30').style.display="block";
    if (!bool_value) {  
      document.getElementById('b30').style.border="1.5px solid #FF1744";
      document.getElementById('b29').style.border="1.5px solid #00bfff";
    }
  }