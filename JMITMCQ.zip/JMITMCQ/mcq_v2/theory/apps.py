from django.apps import AppConfig


class TheoryConfig(AppConfig):
    name = 'theory'
