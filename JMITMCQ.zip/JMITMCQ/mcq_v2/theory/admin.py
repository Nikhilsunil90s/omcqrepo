from django.contrib import admin
from theory.models import Quest
#from theory.models import Answer
# Register your models here.
admin.site.register(Quest)
#admin.site.register(Choice)
#admin.site.register(Answer)
